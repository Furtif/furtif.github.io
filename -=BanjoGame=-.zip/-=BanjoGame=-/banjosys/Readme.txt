0,10Benvindo ao $vbanjo $+ . 

9Em primeiro lugar gostaria de agradecer o script H�brid pela participac�o dos seus "Rumbaar" e addons, e trivia, http://sourceforge.net/projects/mpp/ mIRC POWER PACK, http://www.mircscripts.org, a http://sourceforge.net/projects/mirc-script/ mIRC Script, http://sourceforge.net/projects/xbot-project/ por seus scripts, addons (obiamente alterados por ClubeChaT para uso dos mesmo), entre outros...

9Agrade�o os participantes que d�o ideas novas, scripts, entre outros. Agrade�o tambem a http://jmirc.sourceforge.net pelo apoio em mIRCMobil by clubechat, nao seria demais agradecer a Flash Player adobe e seu support pelo servi�o prestado VideoChat.
9Felicito a todos aqueles que soberam usar este script e explicar o funcionamento do mesmo (e quase automatico). E felicito todos os que fizeram o seu proprio script. E assim, porque e presciso tempo e trabalho para conseguir um.

9Come�a-mos pelo inicio, esta oprerac�o e muito simples, uma vez que voc� abrir o seu script clique no bot�o direito do mouse sobre esta tela.

9Seleccione: �||- ClubeChaT Vincula $bcver -||� - Menu principal, ent�o podera alterar as defini��es ... Nick, Sexo, etc.
9Entre seu dados Nick, Sexo, Fonte etc, estes dados ser�o gardados para futuro.
9Clique em Lista de salas, uma lista aparecera seleccione a sala onde quer entrar se tiver erros do genero "CANNOT JOIN ROOM +c" queira falar com as pessoas responsaveis pela sala para retirarem o Protector.
9Por outro lado, gostaria de fazer uma pequena mensagem a equipa do ClubeChaT, se por acaso usam este script. A mensagem que eu quero � apenas que fa�am aten��o a pessoas pedofilas ou outros e n�o pessoas como nos.

0,4 Material ilegal, Server ou bots (scripts), onde este script entra com ou sem conex�o queiram comunicar a http://www.clubechat.net/contact.php
0,4 Sem mais e agrade�o vossa contribui��o. Lhes deixo minha saudosa sauda��o, a toda equipe ClubeChaT, utilisadores e visitantes.

F1 - 4Ajuda
F2 - 9Menu Principal
F3 - 9Limpar Telas
F4 - 9Fontes do Banjo
F5 - 9Mudar de nick
F6 - 9Mensagens por tempo
F7 - 9Protec��es
F8 - 9Protec��es II
F9 - 9Menu Extra
F10 - 9Lista Salas
F11 - 9Reiniciar Banjo
F12 - 9Exit Banjo

4Agrade�o a todos que leram isto. --=FurtiF�=--.

0,4� Copyright RoboT Banjo 2009. ClubeChaT Communications Inc�

0,11Uma vez lido isto feche a tela clicando no "X" acima.
